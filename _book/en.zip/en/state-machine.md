Incoming transfer state machine Illustration:

<br>

![](image/incoming.png)

<br>

Transfer-out state machine Illustration:

<br>

![](image/outgoing.png)