We provide two versions of API: V1 and V2. We recommend you to use V2 which includes significant improvements comparing to V1.

See full [API documentation](https://nbltrust.github.io/jadepool-api-docs).
