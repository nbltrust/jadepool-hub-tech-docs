### How To Use Electrum Testnet

1. [Download ELectrum](https://electrum.org/#download), Choose the MacOS easy installation, click “Executable for OS X” and the download will be started automatically.

2. After the download is finished, open terminal, paste the command:

```bash
$ cd /Applications/Electrum.app/Contents/MacOS
```

Then paste the command:

```bash
$ ./Electrum --testnet
```

Now Electrum should be opened. 
To create a new wallet, choose a proper name for your wallet and follow the prompted instruction to finish. After your wallet is created, you can find your receiving address and transaction history inside it and send BTC to others.
