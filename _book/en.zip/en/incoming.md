Incoming Transfer State Machine Illustration:

<br>

![](image/incoming.png)
