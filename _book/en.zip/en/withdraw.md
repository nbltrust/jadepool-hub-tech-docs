The amount that user can withdraw is always less than the assets stored at the client platform. It depends on the fee charged by the platform. Jadepool does not have any information about the fee deducted from the client's users. The fee collected from users deducting the mining fee paid by Jadepool is the client's profit. 

Upon withdrawal request, Jadepool will process and transfer the requested value to the user’ s address. Once the transaction is broadcasted and confirmed by the blockchain, Jadepool will inform the client of the withdrawal status. 

Please see [Out Transfer Mode](transfer-pattern.html) for details of Jadepool Hub's out transfer.

<br>

Withdrawal Process Illustration:

![](image/withdraw-proc.png)