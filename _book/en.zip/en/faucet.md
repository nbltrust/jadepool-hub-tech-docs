[BTC Testnet Faucet](https://coinfaucet.eu/en/btc-testnet/)

[ETH Ropsten Faucet](https://faucet.ropsten.be/)

[ETH Kovan Faucet](https://faucet.kovan.network/)

EOS Kylin Faucet：http://faucet.cryptokylin.io/get_token?your_Kylin_account_name

[EOS Jungle Faucet](https://monitor.jungletestnet.io/#faucet)

[QTUM Testnet Faucet](http://testnet-faucet.qtum.info/#!/)

[LTC Testnet Faucet](http://testnet.litecointools.com/)

[XRP Testnet Faucet](https://developers.ripple.com/xrp-test-net-faucet.html)

[COSMOS Testnet Faucet](https://faucet.cosmos.network/)

[NEO Testnet Faucet](http://neo.mywish.io/)

[XLM Testnet Faucet](http://stellarfaucet.info/)
