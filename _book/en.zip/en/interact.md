Obtain Deposit Address Illustration:

<br>

![](image/addr-proc.png)

<br>

Deposit Service Illustration:

<br>

![](image/deposit-proc.png)

<br>

Request Withdrawal Illustration:

<br>

![](image/withdraw-proc.png)
