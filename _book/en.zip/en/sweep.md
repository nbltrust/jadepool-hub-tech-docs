"Hot to cold transfer" service, also known as "cold storage", is designed to ensure the security of the majority of clients’ assets. Clients are able to customize "cold wallet", it can be hardware wallet, vault or mining machine etc.. Admin Management System provides clients ability to set up a “high water level” and "target water level" for each cryptocurrency. Jadepool will initiate an automatic transfer to "cold wallet" automatically and leaves the balance in hot wallet equal to "target water level" once the total value exceeds the “high water level”. 

<br>

Cold Storage Process Illustration:

<br>

![](image/sweep.jpg)
