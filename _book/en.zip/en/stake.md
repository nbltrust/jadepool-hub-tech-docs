Delegation-related Process Illustration:

<br>

![](image/stake.jpg)
